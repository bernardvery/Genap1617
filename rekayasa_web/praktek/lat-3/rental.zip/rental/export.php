<?php
	$db = mysqli_connect("localhost","root","","rental") or die('Tidak dapat tersambung dengan database');
    
    $result = mysqli_query($db, "Select * from dvd");  
	$xml = new SimpleXMLElement('<xml/>');
	while($row = mysqli_fetch_assoc($result)) {
        $mydata = $xml->addChild('dvd');
        $mydata->addChild('id_film',$row['id_film']);
        $mydata->addChild('judul',$row['judul']);
        $mydata->addChild('kategori',$row['kategori']);
        $mydata->addChild('durasi',$row['durasi']);
        $mydata->addChild('sutradara',$row['sutradara']);
    }
	mysqli_close($db);
	
	$fp = fopen("dvd.xml","wb");
	fwrite($fp,$xml->asXML());
	fclose($fp); 
	echo "File XML dvd.xml sudah terupdate";
?>
