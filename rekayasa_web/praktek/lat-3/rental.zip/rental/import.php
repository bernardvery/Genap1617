<html>
<head><title>Daftar Film</title></head>
<body>
<h3>Daftar Film</h3>
<?php
	$dvds = new SimpleXMLElement('dvd.xml', null, true);
	echo "<table border='1'>
		  <tr>
			<td>Id Film</td>
			<td>Judul Film</td>
			<td>Kategori</td>
			<td>Durasi(menit)</td>
			<td>Sutradara</td>
		  </tr>";
	foreach($dvds as $dvd)
	{
		echo "
		<tr>
		<td>{$dvd->id_film}</td>
		<td>{$dvd->judul}</td>
		<td>{$dvd->kategori}</td>
		<td>{$dvd->durasi}</td>
		<td>{$dvd->sutradara}</td>
		</tr>";
	}
	echo "</table>";
?>
</body></html>
